# VS Code 

## Abstract
Some tools, commands for VS code.

<<<<<<< 5fe2b0a25cb14d933b4939b90a159a148bf47923
## Auto-completion
=======
## useful tools
>>>>>>> add lab sensorkit extrinsics between stereo and imu

| tools | functions |
| :---:  | :---:  |
| TabNine | Deep learning-based tools developed by a MSC in Canada |
<<<<<<< 5fe2b0a25cb14d933b4939b90a159a148bf47923
=======
| preview | A previewer of Markdown, ReStructured Text, HTML, Jade, Pug, Mermaid files, Image's URI or CSS properties for Visual Studio Code|
| MATLAB | This extension adds language support for MATLAB to Visual Studio Code. |
| Error Lens | Improve highlighting of errors, warnings and other language diagnostics |
>>>>>>> add lab sensorkit extrinsics between stereo and imu



<!-- ```
├── self-supervised-depth-completion
├── data
|   ├── data_depth_annotated
|   |   ├── train
|   |   ├── val
|   ├── data_depth_velodyne
|   |   ├── train
|   |   ├── val
|   ├── depth_selection
|   |   ├── test_depth_completion_anonymous
|   |   ├── test_depth_prediction_anonymous
|   |   ├── val_selection_cropped
|   └── data_rgb
|   |   ├── train
|   |   ├── val
├── results
``` -->
