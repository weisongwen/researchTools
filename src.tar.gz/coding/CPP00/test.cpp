#include <iostream>
int main(){
    std::cerr<<"hello world \n"<<std::endl;
    return 0;
}